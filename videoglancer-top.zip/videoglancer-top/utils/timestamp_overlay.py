"""
Timestamp overlay module for adding YouTube-style timestamps to frames.
Extracted from the original Colab notebook.
"""

import os
import logging
from PIL import Image, ImageDraw, ImageFont
from config import FONT_PATHS

logger = logging.getLogger(__name__)


def _load_font(size, bold=True):
    """Load a font at the given size from available font paths."""
    paths = FONT_PATHS['bold'] if bold else FONT_PATHS['regular']
    for fp in paths:
        if os.path.exists(fp):
            try:
                return ImageFont.truetype(fp, size)
            except Exception:
                continue
    return ImageFont.load_default()


def add_timestamp_to_frame(frame_path, timestamp_str):
    """
    Adds a timestamp to a frame image (bottom-right corner, no background box).

    Font size is exact per resolution:
      144p = 10px, 240p = 12px, 360p = 16px, 480p = 18px, 720p = 32px
    The text is drawn directly on the frame with a thin
    black stroke for readability against any background — no background
    rectangle, just clean text with a font-relative margin (font_size × 0.5,
    min 4px) for a consistent look at every resolution.

    Args:
        frame_path: Path to the frame image file
        timestamp_str: Timestamp string in format "hh:mm:ss" or "mm:ss" or "0:ss"
    """
    try:
        img = Image.open(frame_path).convert("RGBA")

        img_h = img.size[1]

        # ── Font size per resolution (exact values) ──
        # 144p = 10px, 240p = 12px, 360p = 16px, 480p = 18px, 720p = 32px
        if img_h <= 144:
            font_size = 10
        elif img_h <= 240:
            font_size = 12
        elif img_h <= 360:
            font_size = 16
        elif img_h <= 480:
            font_size = 18
        else:
            font_size = 32
        font = _load_font(font_size, bold=True)
        if font is None:
            font = ImageFont.load_default()

        # Measure text bounds on a temporary draw
        temp_draw = ImageDraw.Draw(img)
        bbox = temp_draw.textbbox((0, 0), timestamp_str, font=font)

        # ── Font-relative margin for consistent look across all resolutions ──
        # 144p=5px, 240p=6px, 360p=8px, 480p=9px, 720p=16px
        margin = max(4, int(font_size * 0.5))

        # Bottom-right position — use bbox[2]/bbox[3] (actual extents) so the
        # 5px margin is measured from the rendered glyph edges, not text_h
        tx = img.size[0] - margin - bbox[2]
        ty = img.size[1] - margin - bbox[3]

        # ── Stroke width proportional to font size ──
        # 1px at small sizes, 2px at larger sizes
        stroke_width = max(1, min(2, font_size // 8))

        # ── Semi-transparent text via overlay compositing ──
        # Draw the text + stroke at ~59% opacity on a transparent overlay,
        # then alpha-composite it so the video frame shows through.
        alpha = 204  # 204/255 = 80%
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        overlay_draw = ImageDraw.Draw(overlay)
        overlay_draw.text(
            (tx, ty), timestamp_str, font=font,
            fill=(255, 255, 255, alpha),
            stroke_width=stroke_width,
            stroke_fill=(0, 0, 0, alpha),
        )

        # Composite the overlay onto the frame
        img = Image.alpha_composite(img, overlay)
        img = img.convert("RGB")
        img.save(frame_path, "JPEG", quality=95)

    except Exception as e:
        logger.warning(f"WARNING: Could not add timestamp to {frame_path}: {e}")


def apply_timestamps_to_frames(frame_paths, extraction_method, interval_seconds, duration, progress_callback=None, pts_map=None):
    """
    Applies YouTube-style timestamps to each frame based on when it was extracted.
    For Time Interval: frame index * interval_seconds.
    For Scene Detection: uses exact PTS timestamps from ffmpeg if available,
                         otherwise evenly distributed across duration (fallback).
    Modifies frames in-place.
    
    Args:
        frame_paths: List of paths to frame images
        extraction_method: Either "Time Interval" or "Scene Detection"
        interval_seconds: Time interval in seconds (for Time Interval method)
        duration: Total video duration in seconds
        progress_callback: Optional (current, total) called per frame
        pts_map: Optional dict mapping frame_path -> exact PTS timestamp in seconds
                 (for Scene Detection with showinfo capture)
    """
    from .youtube_downloader import format_youtube_time
    
    logger.info("\n" + "=" * 70 + "\nAPPLYING TIMESTAMPS TO FRAMES\n" + "=" * 70)
    total = len(frame_paths)
    for i, fp in enumerate(frame_paths):
        # Use exact time from pts_map if available (works for both methods)
        if pts_map and fp in pts_map:
            frame_time = int(round(pts_map[fp]))
        elif extraction_method == "Time Interval":
            frame_time = i * interval_seconds
        elif total > 1:
            frame_time = int((i / (total - 1)) * duration)
        else:
            frame_time = 0
        ts_str = format_youtube_time(int(frame_time))
        add_timestamp_to_frame(fp, ts_str)
        if progress_callback:
            progress_callback(i + 1, total)
        if i % 20 == 0 or i == total - 1:
            logger.info(f"  Stamped {i+1}/{total}: {fp} @ {ts_str}")
    logger.info(f"Timestamps applied to {total} frames.")
    logger.info("=" * 70)
