"""
Frame deduplication module using perceptual hashing and SSIM.
Extracted from the original Colab notebook.
"""

import logging
from PIL import Image
import imagehash
import numpy as np
from skimage.metrics import structural_similarity as ssim

logger = logging.getLogger(__name__)


def deduplicate_frames_intelligent(frame_paths, phash_threshold=5, ssim_threshold=0.98, progress_callback=None, cancel_check=None):
    """
    Post-processes extracted frames to remove duplicates or near-duplicates.
    Uses perceptual hashing (pHash) and SSIM.
    
    Args:
        frame_paths: List of paths to frame images
        phash_threshold: Hamming distance threshold for pHash comparison
        ssim_threshold: SSIM threshold for similarity comparison
        progress_callback: Optional callback function to report progress (removed, unique)
        cancel_check: Optional callable returning True when cancellation is requested
    
    Returns:
        List of unique frame paths
    """
    logger.info("\n" + "=" * 70 + "\nPERFORMING INTELLIGENT FRAME DEDUPLICATION\n" + "=" * 70)
    logger.info(f"INFO: Initial frames: {len(frame_paths)}")
    logger.info(f"INFO: pHash Threshold (Hamming Distance): <{phash_threshold}")
    logger.info(f"INFO: SSIM Threshold: >{ssim_threshold}")

    if not frame_paths:
        logger.info("No frames to deduplicate.")
        return []

    unique_frames = []
    last_kept_frame_path = None
    last_kept_image_pil = None
    last_kept_image_np = None
    last_kept_phash = None

    for i, current_frame_path in enumerate(frame_paths):
        # Check cancellation during the loop so long dedup runs stop instantly
        if cancel_check and cancel_check():
            logger.info("Deduplication cancelled by user")
            # Return what we have so far
            if progress_callback:
                removed = len(frame_paths) - len(unique_frames)
                progress_callback(removed, len(unique_frames), 100)
            return unique_frames if unique_frames else frame_paths[:1]

        try:
            current_image_pil = Image.open(current_frame_path).convert('L')
            current_image_np = np.array(current_image_pil)
            current_phash = imagehash.phash(current_image_pil)

            if last_kept_frame_path is None:
                unique_frames.append(current_frame_path)
                last_kept_frame_path = current_frame_path
                last_kept_image_pil = current_image_pil
                last_kept_image_np = current_image_np
                last_kept_phash = current_phash
                logger.info(f"  Keeping first frame: {current_frame_path}")
                continue

            is_duplicate = False

            if (current_phash - last_kept_phash) <= phash_threshold:
                is_duplicate = True

            if not is_duplicate:
                if current_image_np.shape == last_kept_image_np.shape:
                    # data_range=255 for PIL 'L' mode (8-bit grayscale, 0-255)
                    # Using a hardcoded 255 avoids division by zero on uniform frames
                    # (e.g., solid black/white) where max()-min() would be 0.
                    current_ssim = ssim(last_kept_image_np, current_image_np, data_range=255)
                    if current_ssim >= ssim_threshold:
                        is_duplicate = True

            if not is_duplicate:
                unique_frames.append(current_frame_path)
                last_kept_frame_path = current_frame_path
                last_kept_image_pil = current_image_pil
                last_kept_image_np = current_image_np
                last_kept_phash = current_phash
                logger.info(f"  Keeping unique frame: {current_frame_path}")
                
                # Report progress
                if progress_callback and (i % 3 == 0 or i == len(frame_paths) - 1):
                    removed = (i + 1) - len(unique_frames)
                    pct = min(99, int((i + 1) / len(frame_paths) * 100))
                    progress_callback(removed, len(unique_frames), pct)

        except Exception as e:
            logger.warning(f"WARNING: Could not process frame {current_frame_path}: {e}")
            unique_frames.append(current_frame_path)
            # Don't update last_kept_* variables on error — keeps the previous
            # working frame as the comparison anchor for subsequent frames.
            # Setting them to None would cause cascading TypeError on the
            # next iteration (None - None via imagehash).

    logger.info(f"INFO: Frames after deduplication: {len(unique_frames)}")
    logger.info("=" * 70)
    
    return unique_frames
