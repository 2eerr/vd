"""
YouTube video downloader module using yt-dlp.
Extracted from the original Colab notebook.
"""

import os
import yt_dlp
import json
import logging
import threading
import time
import re
import urllib.request
import urllib.error
import urllib.parse

logger = logging.getLogger(__name__)

# Standard YouTube video heights — used by both get_quality_format() and the quality check
STANDARD_HEIGHTS = (144, 240, 360, 480, 720, 1080, 1440, 2160)


def _is_youtube_bot_error(exc):
    """True if the error should trigger a client fallback retry.

    Covers:
    - Bot/sign-in/captcha blocking (retry with different client)
    - Client-incompatible videos like 'Made for kids' (retry with tv/tv_embedded)
    - Format unavailability (signed URLs expired or format missing for this client)
    """
    msg = str(exc).lower()
    return any(
        token in msg
        for token in (
            # Bot / sign-in / captcha
            'not a bot', 'sign in', 'cookies', 'confirm you', 'bot',
            # Client-incompatible (e.g. android_vr can't play kids videos)
            # Note: intentionally NOT matching 'not available' or 'unavailable'
            # as those catch genuinely deleted/privated videos in metadata extraction.
            'restricted', 'for kids', 'not supported',
            'does not support', 'skipped as they', 'missing a url',
        )
    )


def _parse_playlist_info(info, fallback_url):
    """Parse yt-dlp info dict into (video_urls, playlist_name).

    Each video URL includes &list=PLAYLIST_ID when the source is a playlist,
    so the YouTube card links preserve playlist context (the user stays within
    the playlist when clicking the video link).
    """
    playlist_name = None
    video_urls = []
    # Capture the playlist_id from yt-dlp's info dict so we can append &list=
    # to each individual video URL when the source is a playlist.
    # Fall back to info.get('id') which also holds the playlist ID when
    # extract_flat='in_playlist' is used (as it is in get_playlist_videos).
    playlist_id = info.get('playlist_id') or info.get('id')
    logger.info(f"[_parse_playlist_info] playlist_id={playlist_id!r}, entries={len(info.get('entries', []))}, fallback_url={fallback_url}")

    def _build_video_url(video_id):
        """Build a watch URL with optional &list= context."""
        url = f"https://www.youtube.com/watch?v={video_id}"
        if playlist_id:
            url += f"&list={playlist_id}"
        logger.info(f"[_parse_playlist_info] _build_video_url(id={video_id!r}) -> {url}")
        return url

    if 'entries' in info and info['entries']:
        entries = [e for e in info['entries'] if e]
        if len(entries) > 1:
            if 'title' in info:
                playlist_name = info['title']
                for char in ['/', '\\', ':', '*', '?', '<', '>', '|', '"']:
                    playlist_name = playlist_name.replace(char, '-')
                playlist_name = playlist_name.encode('utf-8', errors='ignore').decode('utf-8')
                playlist_name = playlist_name.strip('.')[:100]
            for entry in entries:
                video_id = entry.get('id')
                entry_url = entry.get('url')
                if video_id:
                    # Always build from video_id + optional playlist_id so that
                    # &list= context is preserved in the YouTube card link.
                    video_urls.append(_build_video_url(video_id))
                elif entry_url:
                    video_urls.append(entry_url)
        elif len(entries) == 1:
            entry = entries[0]
            video_id = entry.get('id')
            entry_url = entry.get('url')
            if video_id:
                video_urls.append(_build_video_url(video_id))
            elif entry_url:
                video_urls.append(entry_url)
    elif info.get('webpage_url'):
        video_urls.append(info['webpage_url'])
    elif info.get('url'):
        video_urls.append(info['url'])
    else:
        video_urls.append(fallback_url)

    if len(video_urls) == 1:
        playlist_name = None

    logger.info(f"[_parse_playlist_info] Returning {len(video_urls)} URLs, playlist_name={playlist_name!r}")
    if video_urls:
        logger.info(f"[_parse_playlist_info] First URL: {video_urls[0]!r}")
    return video_urls, playlist_name


def _extract_info_with_fallback(url, download=False, extra_opts=None):
    """Try to extract info, falling back to player client rotation on bot errors.

    Strategy (matching the working Colab notebook):
    1. Try with clean defaults first — Desktop Chrome UA, full browser headers,
       no player_client override. This works ~95% of the time.
    2. Only if that fails with a bot/sign-in error, try rotating through
       different YouTube player clients as a last resort.
    """
    from config import build_ydl_opts, YOUTUBE_PLAYER_CLIENT_FALLBACKS

    # Step 1: Clean attempt — no player_client override (matches working notebook)
    try:
        clean_opts = build_ydl_opts(**(extra_opts or {}))
        clean_opts['simulate'] = not download
        with yt_dlp.YoutubeDL(clean_opts) as ydl:
            info = ydl.extract_info(url, download=download)
            if info:
                logger.info("yt-dlp OK (clean, no client override)")
                return info, None, None
    except Exception as e:
        if not _is_youtube_bot_error(e):
            # Non-bot error — don't bother rotating, just surface it
            logger.error(f"yt-dlp extraction error: {e}")
            return None, None, e
        logger.warning(f"Clean attempt failed with bot error: {e}")
        logger.warning("Falling back to player client rotation...")

    # Step 2: Fallback — rotate through player clients
    last_error = None
    for clients in YOUTUBE_PLAYER_CLIENT_FALLBACKS:
        opts = build_ydl_opts(player_clients=clients, **(extra_opts or {}))
        opts['simulate'] = not download
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=download)
                if info:
                    logger.info(f"yt-dlp OK (clients={clients})")
                    return info, clients, None
        except Exception as e:
            last_error = e
            logger.warning(f"yt-dlp failed with player_client={clients}: {e}")

    if last_error and _is_youtube_bot_error(last_error):
        logger.error('YouTube blocked the request (bot/sign-in error).')
    return None, None, last_error


def format_youtube_time(seconds):
    """Format seconds to YouTube time format (HH:MM:SS or MM:SS or SS)."""
    seconds = int(seconds)
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    elif minutes > 0:
        return f"{minutes}:{secs:02d}"
    else:
        return f"0:{secs:02d}"


def get_quality_format(selected_quality_str):
    """Convert quality selection to yt-dlp format string with preferred fallbacks.

    We only need the video stream (audio is discarded) — frame extraction uses
    ffmpeg on the raw video file. Video-only formats are preferred because they
    avoid downloading unnecessary audio data and skip the ffmpeg merge step.

    Format string structure (first match wins):
      1. Exact height with preferred codec (avc1, vp9, av01)
      2. Higher heights with preferred codec
      3. Lower heights with preferred codec
      4. Exact height, any codec (broad fallback — ensures resolution)
      5. Higher heights, any codec
      6. Lower heights, any codec
      7. bestvideo (highest res video-only)
      8. Combined formats at requested height (fallback when no video-only exists)
      9. Combined formats at higher heights
      10. best (any combined format, last resort)
    """
    selected_height = int(selected_quality_str.replace('p', ''))
    all_heights = list(STANDARD_HEIGHTS)
    preferred = []

    for codec in ('avc1', 'vp9', 'av01'):
        preferred.append(f"bestvideo[height={selected_height}][vcodec^={codec}]")

    higher = [h for h in all_heights if h > selected_height]
    for codec in ('avc1', 'vp9', 'av01'):
        for h in higher:
            preferred.append(f"bestvideo[height={h}][vcodec^={codec}]")

    lower = [h for h in reversed(all_heights) if h < selected_height]
    for codec in ('avc1', 'vp9', 'av01'):
        for h in lower:
            preferred.append(f"bestvideo[height={h}][vcodec^={codec}]")

    preferred.append(f"bestvideo[height={selected_height}]")
    for h in higher:
        preferred.append(f"bestvideo[height={h}]")
    for h in lower:
        preferred.append(f"bestvideo[height={h}]")

    preferred.append("bestvideo")

    preferred.append(f"best[height={selected_height}]")
    for h in higher:
        preferred.append(f"best[height={h}]")

    preferred.append("best")

    return "/".join(preferred)


def _get_total_bytes_from_format_info(info_dict, quality):
    """Extract total expected download size (bytes) from format info dict.

    We only download video (no audio ever), so estimates are video-only.
    Falls back to bitrate-based estimation when filesizes are unavailable
    (common for YouTube DASH streams).
    Falls back further to quality×duration estimate when format info is empty.
    Returns 0 if total size can't be determined.
    """
    if not info_dict or 'formats' not in info_dict:
        # ── Fallback: estimate from quality × duration ────────────────────────
        QUALITY_ESTIMATE_KBPS = {
            '144p': 300, '240p': 500, '360p': 750, '480p': 1000,
            '720p': 2500, '1080p': 5000, '1440p': 10000, '2160p': 20000,
        }
        kbps = QUALITY_ESTIMATE_KBPS.get(quality)
        duration = info_dict.get('duration', 0) if info_dict else 0
        if kbps and duration > 0:
            estimated = int(duration * kbps * 1000 / 8)
            if estimated > 0:
                logger.debug(f"Estimated from quality×duration: {estimated / (1024*1024):.1f} MB "
                             f"({quality} ~{kbps}kbps @ {duration}s)")
                return estimated
        return 0

    target_height = int(quality.replace('p', ''))

    video_sizes = []  # (height_diff, filesize)

    # Also collect bitrate data for fallback estimation
    best_video_tbr = 0   # total bitrate (kbps) for best video match
    best_video_diff = float('inf')

    for f in info_dict['formats']:
        vcodec = f.get('vcodec') or ''
        f_height = f.get('height') or 0
        f_size = f.get('filesize') or f.get('filesize_approx') or 0
        is_video = vcodec and vcodec != 'none' and f_height > 0

        if not is_video:
            continue

        # Track filesizes
        if f_size:
            video_sizes.append((abs(f_height - target_height), int(f_size)))

        # Track bitrates for fallback
        tbr = f.get('tbr') or 0
        if tbr:
            diff = abs(f_height - target_height)
            if diff < best_video_diff:
                best_video_diff = diff
                best_video_tbr = tbr

    # Best video = closest to target quality height
    if video_sizes:
        video_sizes.sort(key=lambda x: x[0])
        total = video_sizes[0][1]
        logger.debug(f"Computed expected download size from filesize: {total / (1024*1024):.1f} MB")
        return total

    # ── Fallback: estimate from bitrate × duration ────────────────────────
    duration = info_dict.get('duration', 0)
    if duration > 0 and best_video_tbr > 0:
        estimated = int(duration * best_video_tbr * 1000 / 8)
        if estimated > 0:
            logger.debug(f"Estimated download size from bitrate: {estimated / (1024*1024):.1f} MB "
                         f"(video_tbr={best_video_tbr}k @ {duration}s)")
            return estimated

    # ── Final fallback: estimate from quality × duration ──────────────────
    QUALITY_ESTIMATE_KBPS = {
        '144p': 300, '240p': 500, '360p': 750, '480p': 1000,
        '720p': 2500, '1080p': 5000, '1440p': 10000, '2160p': 20000,
    }
    kbps = QUALITY_ESTIMATE_KBPS.get(quality)
    if kbps and duration > 0:
        estimated = int(duration * kbps * 1000 / 8)
        if estimated > 0:
            logger.debug(f"Estimated from quality×duration: {estimated / (1024*1024):.1f} MB "
                         f"({quality} ~{kbps}kbps @ {duration}s)")
            return estimated

    return 0


def _format_bytes(bytes_val):
    """Format byte count to human-readable string (B/KB/MB/GB/TB)."""
    if not bytes_val:
        return "? B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(bytes_val)
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    decimals = 0 if i == 0 else 1
    return f"{size:.{decimals}f} {units[i]}"


def _print_available_formats_info(info_dict):
    """Prints a formatted list of available video formats from a yt-dlp info dictionary."""
    logger.info("\nListing all available formats for this video:")
    logger.info("-" * 70)
    if info_dict and 'formats' in info_dict:
        video_only_formats = []
        audio_only_formats = []
        combined_formats = []

        for f in info_dict['formats']:
            format_str = f"ID: {f.get('format_id', 'N/A')}, Ext: {f.get('ext', 'N/A')}, "
            if f.get('vcodec') and f.get('vcodec') != 'none' and f.get('acodec') and f.get('acodec') != 'none':
                combined_formats.append(format_str + f"Res: {f.get('resolution', 'N/A')}, Fps: {f.get('fps', 'N/A')}, VCodec: {f.get('vcodec', 'N/A')}, ACodec: {f.get('acodec', 'N/A')}, Note: {f.get('format_note', '')}")
            elif f.get('vcodec') and f.get('vcodec') != 'none':
                video_only_formats.append(format_str + f"Res: {f.get('resolution', 'N/A')}, Fps: {f.get('fps', 'N/A')}, VCodec: {f.get('vcodec', 'N/A')}, Note: {f.get('format_note', '')}")
            elif f.get('acodec') and f.get('acodec') != 'none':
                audio_only_formats.append(format_str + f"ACodec: {f.get('acodec', 'N/A')}, Bitrate: {f.get('abr', 'N/A')}k, Note: {f.get('format_note', '')}")

        if combined_formats:
            logger.info("- Combined Video+Audio Formats -")
            for fmt in combined_formats:
                logger.info(fmt)
        if video_only_formats:
            logger.info("- Video-Only Formats (use with bestaudio) -")
            for fmt in video_only_formats:
                logger.info(fmt)
        if audio_only_formats:
            logger.info("- Audio-Only Formats -")
            for fmt in audio_only_formats:
                logger.info(fmt)
        if not (combined_formats or video_only_formats or audio_only_formats):
            logger.info("No recognizable video or audio formats found.")
    else:
        logger.info("Could not retrieve format list.")
    logger.info("\n")


def download_video_file(url, quality, temp_dir, noplaylist_flag=False, concurrent_downloads=16, progress_callback=None, cancel_check=None, prefetched_info=None, prefetched_clients=None, early_metadata_callback=None, status_callback=None):
    """
    Download YouTube video using yt-dlp native downloader.
    
    Args:
        url: YouTube video URL
        quality: Video quality (e.g., '480p')
        temp_dir: Temporary directory for downloads
        noplaylist_flag: Whether to disable playlist download
        concurrent_downloads: Number of concurrent download threads
        progress_callback: Optional callback for download progress
        cancel_check: Optional callable to check if job was cancelled
        prefetched_info: Full yt-dlp info dict from fetch_video_metadata (re-uses extraction)
        prefetched_clients: Working player clients from fetch_video_metadata (re-uses)
    
    Returns:
        Tuple of (local_download_file, video_title, actual_height, duration, fps,
                  thumbnail_url, video_url, error_type)
        where error_type is None on success, 'youtube_blocked' when all download
        clients were exhausted with bot/sign-in errors, or None on other failures.
        Returns (None, ...) on failure
    """
    from config import build_ydl_opts, CONCURRENT_DOWNLOADS, IS_COLAB, CLIENT_UA_MAP

    full_video_info_for_formats = prefetched_info
    working_clients = prefetched_clients
    
    # Track whether early metadata has been sent (format-table extraction or download hook)
    _metadata_sent = [False]

    # Only fetch metadata if not already prefetched — avoids redundant yt-dlp extraction
    # (webpage download, JS challenge solving, format info) which can take 5-10s.
    # Also pipes early metadata to the UI via callback for the YouTube preview card.
    if full_video_info_for_formats is None:
        if status_callback:
            status_callback('Fetching video info...')
        try:
            full_video_info_for_formats, working_clients, meta_err = _extract_info_with_fallback(
                url,
                download=False,
                extra_opts={'noplaylist': noplaylist_flag},
            )
            if meta_err and not full_video_info_for_formats:
                logger.warning(f"Could not fetch video metadata (proceeding to download): {meta_err}")
        except Exception as e:
            logger.warning(f"Metadata fetch failed (proceeding to download anyway): {e}")
            full_video_info_for_formats = None

    # Pipe early metadata to UI if available — runs after extraction (fresh or from prefetch cache)
    # This populates the YouTube preview card with title, thumbnail, duration, and URL.
    if full_video_info_for_formats and early_metadata_callback:
        early_metadata_callback(full_video_info_for_formats)
        _metadata_sent[0] = True

    # ── Determine actual download height from format metadata ──
    # Used by the file monitor and yt-dlp progress hook so every progress
    # message shows the REAL quality being downloaded, not the user's
    # original request when it wasn't available. Stored as a single-element
    # mutable list (closure) so both inner functions can read it.
    _expected_height = [None]
    if full_video_info_for_formats:
        _req_h = int(quality.replace('p', ''))
        _avail = {f.get('height') for f in full_video_info_for_formats.get('formats', [])
                  if f.get('height') in STANDARD_HEIGHTS}
        if _req_h in _avail:
            _expected_height[0] = _req_h
        elif _avail:
            _expected_height[0] = min(_avail, key=lambda h: abs(h - _req_h))

    # Show quality matching status — visible during download loop's fresh extraction (3-5s).
    if full_video_info_for_formats and status_callback:
        if _expected_height[0] and _expected_height[0] != _req_h:
            status_callback(f'Matching {quality} quality...')
            status_callback(f'{quality} not available, selected {_expected_height[0]}p instead...')
        else:
            status_callback(f'Matching {quality} quality...')

    # Show format table from metadata before download (so it's always visible even if cancelled)
    if not IS_COLAB:
        _print_available_formats_info(full_video_info_for_formats)

    output_template = os.path.join(temp_dir, '%(id)s.%(ext)s')

    # Pre-compute total expected bytes from format info (for progress denominator)
    total_expected = _get_total_bytes_from_format_info(full_video_info_for_formats, quality)
    if total_expected > 0:
        logger.info(f"Using pre-computed download size: {_format_bytes(total_expected)}")

    # ── File-size monitor (daemon thread) ──────────────────────────────────
    # This is a safety-net for when yt-dlp's built-in progress hook doesn't
    # fire (rare edge cases). Polls video file(s) on disk for real byte count
    # and reports incremental progress.
    _monitor_stop = threading.Event()
    _filesize_progress = [0, 0, 0]  # [bytes_on_disk, last_reported, bytes_at_last_speed_check]
    _last_speed_check = [time.time()]

    def _file_monitor():
        """Poll temp_dir for download file sizes and report real-time progress.

        When total_expected is available (>0), reports meaningful percentages.
        When total_expected is 0, reports the downloaded bytes with total=0
        so the UI shows "X MB / ?" without a misleading percentage.

        On cancellation, stops monitoring immediately.
        """
        # Files to skip when polling (non-video metadata files)
        _skip_exts = ('.json', '.info.json', '.description', '.nfo')

        while not _monitor_stop.is_set():
            if cancel_check and cancel_check():
                return

            total_bytes = 0
            total = 0
            try:
                for fname in os.listdir(temp_dir):
                    if fname.endswith(_skip_exts):
                        continue
                    fpath = os.path.join(temp_dir, fname)
                    if os.path.isfile(fpath):
                        total_bytes += os.path.getsize(fpath)
            except Exception:
                pass

            if total_bytes > 0:
                total = total_expected if total_expected > 0 else 0

            if total_bytes > 0:
                _filesize_progress[0] = total_bytes
                if progress_callback and total_bytes != _filesize_progress[1]:
                    _filesize_progress[1] = total_bytes
                    speed = 0
                    now = time.time()
                    elapsed = now - _last_speed_check[0]
                    if elapsed >= 0.5:
                        byte_diff = total_bytes - _filesize_progress[2]
                        if byte_diff > 0 and elapsed > 0:
                            speed = byte_diff / elapsed
                        _filesize_progress[2] = total_bytes
                        _last_speed_check[0] = now
                    total = total_expected if total_expected > 0 else 0
                    progress_callback(total_bytes, total, speed, actual_height=_expected_height[0])
            time.sleep(0.3)

    _monitor_thread = threading.Thread(target=_file_monitor, daemon=True)
    _monitor_thread.start()

    # ── yt-dlp progress hook ─────────────────────────────────────────────
    # Tracks max-downloaded to prevent jitter: when downloading fragments in
    # parallel, yt-dlp's downloaded_bytes can temporarily go backward as
    # fragment states update.
    _max_downloaded = [0]
    _detected_height = [None]  # populated first time hook fires with actual format height

    def my_hook(d):
        if cancel_check and cancel_check():
            raise Exception("Download cancelled by user")

        # Fallback: extract early metadata from the download's own yt-dlp extraction
        # (fires when format-table extraction failed but download's internal extraction succeeded)
        if not _metadata_sent[0] and early_metadata_callback and d['status'] == 'downloading':
            info_dict = d.get('info_dict') or {}
            if info_dict.get('title'):
                early_metadata_callback(info_dict)
                _metadata_sent[0] = True

        if d['status'] == 'downloading':
            downloaded = d.get('downloaded_bytes', 0)
            total = d.get('total_bytes') or d.get('total_bytes_estimate', 0)

            # Detect actual resolution being downloaded from the hook's info_dict
            if _detected_height[0] is None:
                info_dict = d.get('info_dict') or {}
                h = info_dict.get('height') or d.get('height')
                if h:
                    _detected_height[0] = int(h)
                else:
                    # Try parsing from format description e.g. "160 - 256x144 (144p)"
                    fmt_str = d.get('format') or ''
                    m = re.search(r'(\d+)p', fmt_str)
                    if m:
                        _detected_height[0] = int(m.group(1))

            # Clamp to max seen to eliminate jitter from parallel fragments
            if downloaded > _max_downloaded[0]:
                _max_downloaded[0] = downloaded
            else:
                downloaded = _max_downloaded[0]

            # When total_bytes is 0 (e.g. fragmented DASH), use the
            # pre-computed total from format info.
            if total <= 0 and total_expected > 0:
                total = total_expected

            # Final fallback: fragment_index / fragment_count (last resort)
            if total <= 0:
                frag_idx = d.get('fragment_index', 0)
                frag_tot = d.get('fragment_count', 0)
                if frag_tot and frag_tot > 0:
                    downloaded = frag_idx
                    total = frag_tot

            if downloaded > 0:
                _filesize_progress[0] = downloaded
                _filesize_progress[1] = downloaded
                if progress_callback:
                    progress_callback(downloaded, total, actual_height=_detected_height[0] or _expected_height[0])

    # ── Base download options (shared across fallback attempts) ──
    base_opts = {
        'format': get_quality_format(quality),
        'outtmpl': output_template,
        'simulate': False,
        'progress_hooks': [my_hook] if progress_callback else [],
        'verbose': not IS_COLAB,
        'concurrent_fragment_downloads': concurrent_downloads,
        'ratelimit': None,
        'http_chunk_size': 10485760,  # 10 MiB chunks for more efficient HTTP reads
        'nopostprocessors': True,     # don't download audio just to merge it
    }

    local_download_file = None
    video_title = 'untitled_video'
    actual_height = 'Unknown'
    duration = 0
    fps = 25
    thumbnail_url = ''

    # ── Download with player client + UA rotation ─────────────────────────
    # Each entry in CLIENT_UA_MAP pairs a YouTube player client combination
    # with a matching user agent string, so each attempt looks like a real
    # device/browser making the request, reducing fingerprinting risk.
    # Order (8 attempts):
    #   1. default (android_vr)      → Linux Chrome/125   (matches Colab)
    #   2. android + ios             → Android Chrome/125
    #   3. web + web_safari          → Windows Chrome/125
    #   4. android + web             → Android Firefox/129
    #   5. ios + mweb                → iOS Safari/17.5
    #   6. mweb + android            → macOS Safari/17.5
    #   7. tv + tv_embedded          → Linux Chrome/125
    #   8. web only                  → Windows Edge/125
    download_attempts = CLIENT_UA_MAP
    total_attempts = len(download_attempts)

    last_error = None
    info = None

    for attempt_idx, attempt in enumerate(download_attempts):
        attempt_clients = attempt['clients']
        attempt_label = attempt['label']
        attempt_ua = attempt['ua_summary']
        attempt_headers = attempt['headers']
        attempt_num = attempt_idx + 1

        # Log clearly which client + UA is being used
        logger.info(
            f"[Attempt {attempt_num}/{total_attempts}] "
            f"Client: {attempt_label}, "
            f"UA: {attempt_ua}"
        )

        # Show progressive status in the UI
        if status_callback:
            if attempt_idx == 0:
                pass  # First attempt — no status needed yet
            elif attempt_idx == total_attempts - 1:
                status_callback(
                    f'Attempt {attempt_num}/{total_attempts}: '
                    f'Trying {attempt_label} with {attempt_ua} (last option)...'
                )
            else:
                status_callback(
                    f'Attempt {attempt_num}/{total_attempts}: '
                    f'Blocked, trying {attempt_label} with {attempt_ua}...'
                )

        try:
            # Build opts with this attempt's client (fresh on every attempt)
            # When attempt_clients is None, no client override is set — yt-dlp
            # uses its own defaults which include android_vr (progressive DASH).
            ydl_opts = build_ydl_opts(
                player_clients=attempt_clients,
                noplaylist=noplaylist_flag,
            )
            # Override headers with the UA matching this client
            ydl_opts['http_headers'] = attempt_headers.copy()
            ydl_opts.update(base_opts)

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                # Always do a fresh extract_info(url, download=True) — never reuse
                # the metadata info dict via process_ie_result. The metadata dict's
                # format URLs can be stale or cause yt-dlp to re-select different
                # formats than what the format string requested, leading to 403 errors.
                # process_ie_result also re-processes formats through the download
                # pipeline which can pick video+audio merge pairs even with
                # nopostprocessors=True. A fresh extraction costs ~3-5s but is reliable.
                info = ydl.extract_info(url, download=True)

            last_error = None
            break  # success

        except Exception as e:
            last_error = e

            if cancel_check and cancel_check():
                logger.info("Download cancelled by user")
                return None, None, None, None, None, None, None, None

            # Non-bot error — surface immediately, no retry
            if not _is_youtube_bot_error(e):
                logger.error(f"❌ Failed to download video: {e}")
                return None, None, None, None, None, None, None, None

            if attempt_idx < total_attempts - 1:
                logger.warning(
                    f"[Attempt {attempt_num}/{total_attempts}] "
                    f"Client {attempt_label} ({attempt_ua}) failed with bot error. "
                    f"Trying next..."
                )
            else:
                logger.error(
                    f"❌ [Attempt {attempt_num}/{total_attempts}] "
                    f"All {total_attempts} download attempts exhausted. "
                    f"Last error: {e}"
                )
                return None, None, None, None, None, None, None, 'youtube_blocked'

    # ── Process successful download info ──
    if info:
        # Also show format table from the actual download client (overrides metadata version)
        if not IS_COLAB:
            logger.info("[Formats from download client — overrides metadata table above]")
            _print_available_formats_info(info)

        video_title = info.get('title', 'untitled_video')
        actual_height = info.get('height', 'Unknown')
        duration = info.get('duration', 0)
        fps = info.get('fps', 25)

        thumbnail_url = info.get('thumbnail', '')

        # Determine file path — prefer info.filepath (filled by yt-dlp after download),
        # then fall back to template-based path, then scan temp_dir
        local_download_file = info.get('filepath')
        if not local_download_file:
            video_id = info.get('id', '')
            ext = info.get('ext', 'mp4')
            local_download_file = os.path.join(temp_dir, f"{video_id}.{ext}")
        if not os.path.exists(local_download_file):
            # Fallback: scan temp_dir for any non-metadata file
            for fname in os.listdir(temp_dir):
                fpath = os.path.join(temp_dir, fname)
                if os.path.isfile(fpath) and not fname.endswith(('.json', '.info.json', '.description', '.nfo')):
                    local_download_file = fpath
                    break

        logger.info(f"✓ Video downloaded to: {local_download_file}")

        logger.info("\nDOWNLOADED VIDEO DETAILS")
        logger.info("-" * 70)
        logger.info(f"Original URL: {url}")
        logger.info(f"Video Title: {video_title}")
        logger.info(f"Target Quality: {quality}")
        logger.info(f"Actual Downloaded Height: {info.get('height', 'N/A')}p")

        downloaded_format = next((f for f in info.get('formats', []) if f.get('format_id') == info.get('format_id')), None)
        if downloaded_format:
            logger.info(f"Downloading Format ID: {downloaded_format.get('format_id', 'N/A')}")
            logger.info(f"Container/Ext: {downloaded_format.get('ext', 'N/A')}")
            logger.info(f"Video Codec: {downloaded_format.get('vcodec', 'N/A')}")
            logger.info(f"Audio Codec: {downloaded_format.get('acodec', 'N/A')}")
        else:
            logger.info(f"Downloading Format ID: {info.get('format_id', 'N/A')}")
            logger.info(f"Container/Ext: {info.get('ext', 'N/A')}")
            logger.info(f"Video Codec: {info.get('vcodec', 'N/A')}")
            logger.info(f"Audio Codec: {info.get('acodec', 'N/A')}")

        logger.info(f"Concurrent Download Threads: {concurrent_downloads}")

        file_size_bytes = info.get('filesize', info.get('filesize_approx', 'N/A'))
        if isinstance(file_size_bytes, (int, float)):
            logger.info(f"File Size: {file_size_bytes / (1024*1024):.2f} MB")
        else:
            logger.info(f"File Size: N/A")

        logger.info(f"FPS: {fps}")
        logger.info(f"Duration: {format_youtube_time(int(duration))}")
        logger.info(f"Local Path: {local_download_file}")
        logger.info("=" * 70)

    else:
        logger.error("❌ yt-dlp did not return info after download.")
        return None, None, None, None, None, None, None, None

    canonical_url = info.get('webpage_url', url) if info else url
    logger.info(f"[download_video_file] url param={url!r}, canonical_url from yt-dlp={canonical_url!r}")
    # Preserve &list= playlist context from the original URL when yt-dlp's
    # webpage_url doesn't include it. This ensures the YouTube card in the
    # processing page and PDF/PPTX info page links to the video with its
    # playlist context intact.
    if url and 'list=' in url and 'list=' not in canonical_url:
        m = re.search(r'[?&]list=([^&]+)', url)
        if m and f'list={m.group(1)}' not in canonical_url:
            sep = '&' if '?' in canonical_url else '?'
            canonical_url += f'{sep}list={m.group(1)}'
            logger.info(f"[download_video_file] Appended &list= -> {canonical_url!r}")
        else:
            logger.info(f"[download_video_file] list= found in url but no match or already in canonical")
    else:
        logger.info(f"[download_video_file] No &list= to preserve (url has list: {'list=' in url if url else False}, canonical has list: {'list=' in canonical_url if canonical_url else False})")
    logger.info(f"[download_video_file] Returning canonical_url={canonical_url!r}")
    return local_download_file, video_title, actual_height, duration, fps, thumbnail_url, canonical_url, None


def fetch_video_metadata(url):
    """Fetch video metadata (title, duration, thumbnail) without downloading.

    Uses yt-dlp's extract_info with download=False for a quick metadata-only fetch.
    Returns a tuple (simple_meta, full_info, working_clients) where:
        - simple_meta: dict with 'title', 'duration', 'thumbnail_url' keys
        - full_info: the complete yt-dlp info dict (for re-use in download_video_file)
        - working_clients: the player client that worked (for re-use)
    Returns (None, None, None) on failure.
    """
    logger.info("\n" + "=" * 70 + "\nFETCHING VIDEO INFO\n" + "=" * 70)
    try:
        info, working_clients, meta_err = _extract_info_with_fallback(url, download=False)
        if info:
            title = info.get('title', '')
            duration = info.get('duration')
            # yt-dlp often returns the best thumbnail URL under 'thumbnail'
            thumbnail_url = info.get('thumbnail', '')
            if not thumbnail_url:
                thumbnails = info.get('thumbnails', [])
                if thumbnails:
                    # Prefer the highest-res thumbnail
                    thumbnail_url = thumbnails[-1].get('url', '')
            logger.info(f"Fetched video metadata: title={title!r}, duration={duration}")
            return (
                {'title': title, 'duration': duration, 'thumbnail_url': thumbnail_url},
                info,
                working_clients,
            )
        logger.warning("yt-dlp returned no info for metadata fetch")
    except Exception as e:
        logger.warning(f"Failed to fetch video metadata: {e}")
    return None, None, None


def fetch_oembed_metadata(url):
    """Fetch video title and thumbnail URL from YouTube's oEmbed API (~200ms).

    This is a lightweight alternative to yt-dlp's full extraction. It returns
    basic metadata (title, thumbnail_url, author_name) in a single HTTP request
    without needing to parse YouTube's webpage or solve JavaScript challenges.

    oEmbed endpoint: https://www.youtube.com/oembed?url={url}&format=json

    Returns a dict with 'title', 'thumbnail_url', 'author_name' or None on failure.
    """
    try:
        oembed_url = f'https://www.youtube.com/oembed?url={urllib.parse.quote(url, safe="")}&format=json'
        req = urllib.request.Request(oembed_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status != 200:
                logger.warning(f"oEmbed returned HTTP {resp.status}")
                return None
            data = json.loads(resp.read().decode('utf-8'))
            result = {
                'title': data.get('title', ''),
                'thumbnail_url': data.get('thumbnail_url', ''),
                'author_name': data.get('author_name', ''),
            }
            logger.info(f"oEmbed metadata: title={result['title']!r}")
            return result
    except urllib.error.HTTPError as e:
        logger.warning(f"oEmbed HTTP error: {e.code} {e.reason}")
    except urllib.error.URLError as e:
        logger.warning(f"oEmbed URL error: {e.reason}")
    except json.JSONDecodeError as e:
        logger.warning(f"oEmbed JSON parse error: {e}")
    except Exception as e:
        logger.warning(f"oEmbed fetch failed: {e}")
    return None


def parse_youtube_url(url):
    """Determine if a YouTube URL is a single video or playlist using only URL parsing (no yt-dlp).

    Returns:
        tuple: ('single', video_id), ('playlist', playlist_id), or ('unknown', None)
    """
    from urllib.parse import urlparse, parse_qs
    import re

    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    host = parsed.hostname or ''
    path = parsed.path.rstrip('/')

    # youtu.be/VIDEO_ID[?params]
    if 'youtu.be' in host:
        video_id = path.lstrip('/').split('?')[0].split('/')[0]
        if video_id and re.match(r'^[a-zA-Z0-9_-]{11}$', video_id):
            return ('single', video_id)
        return ('unknown', None)

    # Must be a youtube.com domain (or subdomain)
    if 'youtube.com' not in host and 'youtubekids.com' not in host:
        return ('unknown', None)

    # /playlist?list=XXX → playlist (no video ID)
    if path.startswith('/playlist'):
        lid = query.get('list', [None])[0]
        if lid:
            return ('playlist', lid)
        return ('unknown', None)

    # /watch?v=XXX[&list=YYY] → single (video ID present)
    if 'v' in query:
        return ('single', query['v'][0])

    # /embed/VIDEO_ID, /v/VIDEO_ID, /shorts/VIDEO_ID, /live/VIDEO_ID
    for prefix in ('/embed/', '/v/', '/shorts/', '/live/'):
        if prefix in path:
            idx = path.index(prefix) + len(prefix)
            seg = path[idx:].split('/')[0].split('?')[0]
            if seg and re.match(r'^[a-zA-Z0-9_-]{11}$', seg):
                return ('single', seg)

    # Has list param but no video ID → playlist
    if 'list' in query:
        return ('playlist', query['list'][0])

    return ('unknown', None)


def get_playlist_videos(url):
    """Extract all video URLs from a playlist or single video.

    Uses yt-dlp directly with playlist-appropriate options — NOT the
    player-client fallback system (which is designed for single-video
    extraction and can break the youtube:tab extractor).
    """
    try:
        from config import resolve_ffmpeg
        opts = {
            'noplaylist': False,
            'extract_flat': 'in_playlist',
            'quiet': True,
            'ignoreerrors': True,
            'no_warnings': False,
            'nocheckcertificate': True,
            'geo_bypass': True,
            'socket_timeout': 30,
            'retries': 15,
            'remote_components': ['ejs:github'],
        }
        ffmpeg_path = resolve_ffmpeg()
        if ffmpeg_path:
            opts['ffmpeg_location'] = ffmpeg_path

        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)

        if not info:
            logger.error(f"yt-dlp returned no information for URL: {url}")
            return ([], None)

        video_urls, playlist_name = _parse_playlist_info(info, url)
        if not video_urls:
            logger.error(f"No video URLs extracted from: {url}")
            return ([], None)

        logger.info(f"Extracted {len(video_urls)} URL(s) from playlist")
        return video_urls, playlist_name

    except Exception as e:
        logger.error(f"Failed to extract videos from URL: {url}")
        logger.error(str(e))
        return ([], None)
